export default function Signup() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-950 px-4">
      <div className="w-full max-w-md rounded-xl bg-zinc-900 p-8 shadow-xl">
        <h1 className="text-3xl font-bold text-white text-center">
          Create Account
        </h1>
        <p className="mt-2 text-center text-zinc-400">
          Start your TechLingo journey
        </p>

        <form className="mt-8 space-y-4">
          <input
            type="text"
            placeholder="Username"
            className="w-full rounded-lg bg-zinc-800 px-4 py-3 text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />

          <input
            type="password"
            placeholder="Password"
            className="w-full rounded-lg bg-zinc-800 px-4 py-3 text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />

          <input
            type="text"
            placeholder="OpenRouter API Key"
            className="w-full rounded-lg bg-zinc-800 px-4 py-3 text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />

          <input
            type="text"
            placeholder="Model (e.g. gpt-4o)"
            className="w-full rounded-lg bg-zinc-800 px-4 py-3 text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />

          <button
            type="submit"
            className="mt-4 w-full rounded-lg bg-indigo-600 py-3 font-semibold text-white hover:bg-indigo-500 transition"
          >
            Sign Up
          </button>
        </form>
      </div>
    </div>
  );
}
