export default function Login() {
  return (
    // CONTAINER: overflow-hidden ensures background blobs don't cause scrollbars
    <div className="relative min-h-screen flex items-center justify-center bg-zinc-950 overflow-hidden px-4 selection:bg-indigo-500 selection:text-white">
      
      {/* --- FUNKY BACKGROUND ELEMENTS --- */}
      {/* Blob 1: Top Left - Purple/Pink */}
      <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-[128px] opacity-40 animate-pulse"></div>
      {/* Blob 2: Bottom Right - Cyan/Blue */}
      <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-cyan-600 rounded-full mix-blend-multiply filter blur-[128px] opacity-40 animate-pulse delay-1000"></div>
      {/* Blob 3: Center - Indigo (Floating) */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-indigo-600 rounded-full mix-blend-multiply filter blur-[96px] opacity-30 animate-blob"></div>

      {/* --- GLASS CARD --- */}
      <div className="relative w-full max-w-md">
        {/* Decorative border gradient for the card */}
        <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-600 to-purple-600 rounded-2xl blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
        
        <div className="relative rounded-2xl bg-zinc-900/80 backdrop-blur-xl border border-white/10 p-8 shadow-2xl">
          
          {/* Header */}
          <div className="mb-8 text-center">
            <h1 className="text-4xl font-bold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400">
              Welcome Back
            </h1>
            <p className="text-zinc-400 text-sm">
              Enter the portal to continue learning
            </p>
          </div>

          <form className="space-y-6">
            {/* Username Input Group */}
            <div className="group space-y-2">
              <label className="text-xs font-medium text-zinc-400 group-focus-within:text-indigo-400 transition-colors uppercase tracking-wider">
                Username
              </label>
              <input
                type="text"
                placeholder="cyber_student"
                className="w-full rounded-lg bg-zinc-950/50 border border-zinc-800 px-4 py-3 text-white placeholder-zinc-600 outline-none transition-all duration-300 focus:border-indigo-500 focus:bg-zinc-900/80 focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>

            {/* Password Input Group */}
            <div className="group space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-xs font-medium text-zinc-400 group-focus-within:text-indigo-400 transition-colors uppercase tracking-wider">
                  Password
                </label>
                <a href="#" className="text-xs text-zinc-500 hover:text-white transition-colors">
                  Forgot?
                </a>
              </div>
              <input
                type="password"
                placeholder="••••••••"
                className="w-full rounded-lg bg-zinc-950/50 border border-zinc-800 px-4 py-3 text-white placeholder-zinc-600 outline-none transition-all duration-300 focus:border-indigo-500 focus:bg-zinc-900/80 focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>

            {/* Funky Button */}
            <button
              type="submit"
              className="group relative w-full overflow-hidden rounded-lg bg-indigo-600 p-[1px] focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:ring-offset-2 focus:ring-offset-zinc-900"
            >
              {/* Button Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 opacity-0 transition-opacity duration-300 group-hover:opacity-100"></div>
              
              {/* Button Content */}
              <div className="relative flex items-center justify-center bg-zinc-900 group-hover:bg-transparent transition-colors duration-300 rounded-lg px-4 py-3">
                <span className="font-semibold text-white group-hover:scale-105 transition-transform duration-300">
                  Login to Dashboard
                </span>
                
                {/* Arrow Icon that slides in on hover */}
                <svg 
                  className="ml-2 w-4 h-4 text-white -translate-x-2 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all duration-300" 
                  fill="none" viewBox="0 0 24 24" stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </div>
            </button>
          </form>

          {/* Social / Divider */}
          <div className="mt-8">
            <div className="relative flex items-center justify-center">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-zinc-800"></div>
              </div>
              <span className="relative bg-zinc-900 px-2 text-xs text-zinc-500">
                Or continue with
              </span>
            </div>
            
            <div className="mt-4 grid grid-cols-2 gap-3">
              <button className="flex items-center justify-center rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 hover:border-zinc-600 py-2.5 transition-all text-white text-sm font-medium">
                 Google
              </button>
              <button className="flex items-center justify-center rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 hover:border-zinc-600 py-2.5 transition-all text-white text-sm font-medium">
                 GitHub
              </button>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  );
}