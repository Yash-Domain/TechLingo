export default function Dashboard() {
  return <h1 className="text-2xl">Dashboard</h1>;
}
