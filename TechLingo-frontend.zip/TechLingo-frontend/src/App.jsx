import AppRouter from "./router/Approuter";

export default function App() {
  return <AppRouter />;
}
